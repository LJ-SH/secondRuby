#encoding: utf-8
#I18n.default_locale = "zh-CN".to_sym

LANGUAGES = [
  ['English', 'en'],
  ['中文', 'zh-CN']
]

