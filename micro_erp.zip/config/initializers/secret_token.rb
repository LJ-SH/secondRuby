# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MicroErp::Application.config.secret_token = '1adec7761b81a75328e0a1a0b70b6c4346667c7aee47d10b11b4dfd794882a8f0d88db7ab72576dd5cbea3407a5bcbf8969d3f0206f591ad3dedf0cdef2ea594'
